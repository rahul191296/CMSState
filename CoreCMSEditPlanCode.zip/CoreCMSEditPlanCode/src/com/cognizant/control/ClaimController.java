package com.cognizant.control;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Claim;
import com.cognizant.model.ClaimModel;
import com.cognizant.service.ClaimService;


@Controller
public class ClaimController {
	
	
	
	@Autowired
	@Qualifier("ClaimValidator")
	private Validator claimvalidator;
	
	@Autowired
	private ClaimService claimService;
	
	 @ModelAttribute("claimModel")
		public ClaimModel createClaimModelObject() {
			ClaimModel claimModel = new ClaimModel();
			return claimModel;
		}
	 
		@RequestMapping(value = "viewonememberclaim.htm", method = RequestMethod.GET)
		public ModelAndView viewOneMemberClaim(@RequestParam("claimId")int claimId) {
			ModelAndView mv = new ModelAndView();

			List<Claim> oneMemberClaim = claimService.getOneClaim(claimId);

			mv.addObject("oneMemberClaim",oneMemberClaim);

			mv.setViewName("viewonememberclaim");
			return mv;
		}
		

		@RequestMapping(value = "viewnewclaim.htm", method = RequestMethod.GET)
		public ModelAndView viewNewClaim() {
			ModelAndView mv = new ModelAndView();

			List<Claim> newClaimList = claimService.getNewClaim();
		
			mv.addObject("newClaimList", newClaimList);

			mv.setViewName("viewnewclaim");
			return mv;
		}
		
		
		

		@RequestMapping(value = "viewprocessedclaim.htm", method = RequestMethod.GET)
		public ModelAndView viewProcessedClaim() {
			ModelAndView mv = new ModelAndView();

			List<Claim> processedClaimList = claimService.getProcessedClaim();

			mv.addObject("processedClaimList", processedClaimList );

			mv.setViewName("viewprocessedclaim");
			return mv;
		}
	   
		
		@RequestMapping(value = "viewoneclaim.htm", method = RequestMethod.GET)
		public ModelAndView viewOneClaim(@RequestParam("claimId")int claimId) {
			ModelAndView mv = new ModelAndView();

			List<Claim> oneClaim = claimService.getOneClaim(claimId);

			mv.addObject("oneClaim",oneClaim);

			mv.setViewName("viewoneclaim");
			return mv;
		}
		
		@RequestMapping(value="changeRequestStatus.htm",method=RequestMethod.GET)
		public ModelAndView changeClaimStatus(@RequestParam("claimId")int claimId,@RequestParam("memberId")String memberId,@RequestParam("action")String action){
			ModelAndView mv=new ModelAndView();

			
			if(action.equals("Accept")){
			boolean acceptClaim=claimService.acceptClaimRequest(claimId , memberId);
			    if(acceptClaim)
				mv.setViewName("admin");
			    return mv;
			}else{
				
				boolean rejectClaim = claimService.rejectClaimRequest(claimId, memberId);
				if(rejectClaim)
				mv.setViewName("admin");
				return mv;
			}
	}
		
		
		
}
