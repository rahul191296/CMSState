package com.cognizant.control;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


import com.cognizant.entity.Claim;
import com.cognizant.entity.Member;
import com.cognizant.entity.MemberRegistrationRequest;
import com.cognizant.entity.PlanCode;
import com.cognizant.model.AdminModel;
import com.cognizant.model.MemberModel;
import com.cognizant.service.AdminService;
import com.cognizant.service.ClaimService;
import com.cognizant.service.MemberRegistrationRequestService;
import com.cognizant.service.MemberService;
import com.cognizant.service.PlanCodeService;
import com.cognizant.validation.AdminRagistrationValidator;
import com.cognizant.validation.MemberRegistrationValidator;


@Controller
//@SessionAttributes("newMemberList")
public class AdminController {
	@Autowired
	@Qualifier("AdminValidator")
	private Validator adminvalidator;

	@Autowired
	@Qualifier("MemberValidator")
	private Validator membervalidator;
	
	
	@Autowired
	private MemberRegistrationRequestService memberRegistrationRequestService;
	
     //   -----------------------------------------------ADMIN
	@Autowired
	private AdminService adminService;

	
	@ModelAttribute("adminModel")
	public AdminModel createAdminModelObject() {
		AdminModel adminModel = new AdminModel();
		return adminModel;

	}
	
	@RequestMapping(value = "adminlogin.htm", method = RequestMethod.GET)
	public String loadLoginForm() {
		return "adminlogin";
	}

	

	@RequestMapping(value = "doadminlogin.htm", method = RequestMethod.POST)
	public ModelAndView doAdminLogin(@ModelAttribute("adminModel") AdminModel adminModel, Errors errors, HttpSession session) {
		ValidationUtils.invokeValidator(adminvalidator, adminModel, errors);
		ModelAndView mv = new ModelAndView();

		if (errors.hasErrors()) {
			mv.setViewName("adminlogin");
		} else {
	
			mv.setViewName("admin");
			}
		
		return mv;
	}
	
	@RequestMapping(value = "adminregistration.htm", method = RequestMethod.GET)
	public String loadAdminRegistrationForm() {

		return "adminregistration";
	}
	
	 @Autowired
	  private AdminRagistrationValidator adminRagistrationValidator;
	  
	 
	  
	
	  @RequestMapping(value = "registerProcessAdmin.htm", method = RequestMethod.POST)
	  public ModelAndView addUser(@ModelAttribute("adminModel") AdminModel adminModel,Errors error) 
	  {
		 
		  ModelAndView mv=new ModelAndView();
	  ValidationUtils.invokeValidator(adminRagistrationValidator, adminModel, error);
		  
		  if(error.hasErrors())
		  {
			  mv.setViewName("adminregistration");
		  }
		 
		  else{
		  if(adminService.persistAdmin(adminModel)==true)
		  {
			  String id=adminService.getId();
			  mv.addObject("id",id);
			  mv.setViewName("registrationsuccess");
		  }
		 else
	        mv.setViewName("adminregistration");
		  }
		  return mv;
	 }

	// ---------------------------------------------------------
	

	
	// -------------------------------------------------------MEMBER
	  
	  
	
	@ModelAttribute("memberModel")
	public MemberModel createMemberModelObject() {
		MemberModel memberModel = new MemberModel();
		return memberModel;
	}
	
	
	@RequestMapping(value = "memberlogin.htm", method = RequestMethod.GET)
	public String VendorLoginForm() {
		return "memberlogin";
	}

	
	
	
	@RequestMapping(value = "domemberlogin.htm", method = RequestMethod.POST)
	public ModelAndView doMemberLogin(@ModelAttribute("memberModel") MemberModel memberModel, Errors errors, HttpSession session) {
		List<MemberRegistrationRequest>  ApprovedMemberList =  memberRegistrationRequestService.getAllApprovedRegistration();
		MemberRegistrationRequest	memberStatusObj=null;
		String	registrationStatus="New";
	    String	memberStatusId=memberModel.getMemberId();
	   // System.out.println(memberStatusId);
	    for(MemberRegistrationRequest temp : ApprovedMemberList){
	  	if(temp.getMemberId().equals(memberStatusId)){
	    	registrationStatus=	temp.getRegistrationStatus();
	         break;
	    	//System.out.println(temp.getMemberId());
	    	}
	    	System.out.println(	temp.getRegistrationStatus());
	    	boolean res=temp.getMemberId().equals(memberStatusId);
	    	System.out.println(res);
	    	System.out.println(temp.getMemberId());
	    	System.out.println(temp.getMemberId().length());
	    	
	    	System.out.println(memberStatusId);
	    	System.out.println(memberStatusId.length());
	    	
	   // 	registrationStatus=	memberStatusObj.getRegistrationStatus();
	   }
	/* if(newMemberList.contains(memberStatusId)){
		int indexOfMemberId=newMemberList.indexOf(memberStatusId);
		MemberRegistrationRequest	memberStatusObj=newMemberList.get(indexOfMemberId);
		registrationStatus=	memberStatusObj.getRegistrationStatus();
	}
	*/
	ValidationUtils.invokeValidator(membervalidator, memberModel, errors);
		ModelAndView mv = new ModelAndView();
		if (errors.hasErrors()) {
			mv.setViewName("memberlogin");
	} else {
	if(registrationStatus.equals("Approved")){
			mv.setViewName("admin");
			}
		else{
			mv.addObject("msg","You are not Approved");
			mv.setViewName("memberlogin");
		}
		}
		return mv;
	}
	
	@RequestMapping(value = "memberregistration.htm", method = RequestMethod.GET)
	public String loadMemberRegistrationForm() {
		return "memberregistration";
	}
	
	
	 @Autowired
	  private MemberRegistrationValidator memberRagistrationValidator;
	 
	 
	 @RequestMapping(value = "registerProcessMember.htm", method = RequestMethod.POST)
	  public ModelAndView addUserM(@ModelAttribute("memberModel") MemberModel memberModel,Errors error) 
	  {
		 
		  ModelAndView mv=new ModelAndView();
		  ValidationUtils.invokeValidator(memberRagistrationValidator, memberModel, error);
		 
		  if(error.hasErrors())
		  {
			  mv.setViewName("memberregistration");
		  }
		  else
		  {
		 // ###############################
			  
			  
	  if(memberService.persistMember(memberModel)==true)
	  {
	
		  String id=memberService.getId();
		  mv.addObject("id",id);
	  mv.setViewName("memberregisuccess");
	  }
	  else
		  mv.setViewName("memberregistration");
		  }
	return mv;
	 
	  }


	
	

	// MEMBER REGISTRATION STATUS
	@ModelAttribute("newMemberList")
	public List<MemberRegistrationRequest> mRRS(){
		List<MemberRegistrationRequest> newMemberList = memberRegistrationRequestService.getAllNewRegistration(); 
		 return newMemberList;
	}
	
	
	@RequestMapping(value = "viewnewmember.htm", method = RequestMethod.GET)
	public ModelAndView viewNewMember(@ModelAttribute("newMemberList")List<MemberRegistrationRequest> newMemberList) {
		
		ModelAndView mv = new ModelAndView();
		

		
		
//		System.out.println(newMemberList);
		mv.addObject("newMemberList",newMemberList);
		
		mv.setViewName("viewnewmember");
		return mv;
	}
	
	
	// -----------------------------------------------------------------LOGOUT

	@RequestMapping(value = "logout.htm", method = RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		session.invalidate();
		mv.setViewName("logoutpage");
		return mv;
	}

	//-------------------------------------------------------------------------CLAIM
	
	@Autowired
	private ClaimService claimService;

	@RequestMapping(value = "viewnewclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewNewClaim() {
		ModelAndView mv = new ModelAndView();

		List<Claim> newClaimList = claimService.getNewClaim();

		mv.addObject("newClaimList", newClaimList);

		mv.setViewName("viewnewclaim");
		return mv;
	}
	
	
	

	@RequestMapping(value = "viewprocessedclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewProcessedClaim() {
		ModelAndView mv = new ModelAndView();

		List<Claim> processedClaimList = claimService.getProcessedClaim();

		mv.addObject("processedClaimList", processedClaimList );

		mv.setViewName("viewprocessedclaim");
		return mv;
	}
   
	
	@RequestMapping(value = "viewoneclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewOneClaim(@RequestParam("claimId")int claimId) {
		ModelAndView mv = new ModelAndView();

		List<Claim> oneClaim = claimService.getOneClaim(claimId);

		mv.addObject("oneClaim",oneClaim);

		mv.setViewName("viewoneclaim");
		return mv;
	}
	//-------------------------------------------------------------Claim Processing
	
	@RequestMapping(value="changeRequestStatus.htm",method=RequestMethod.GET)
	public ModelAndView changeClaimStatus(@RequestParam("claimId")int claimId,@RequestParam("memberId")int memberId,@RequestParam("action")String action){
		ModelAndView mv=new ModelAndView();

		
		if(action.equals("Accept")){
		boolean acceptClaim=claimService.acceptClaimRequest(claimId , memberId);
		    if(acceptClaim)
			mv.setViewName("admin");
		    return mv;
		}else{
			
			boolean rejectClaim = claimService.rejectClaimRequest(claimId, memberId);
			if(rejectClaim)
			mv.setViewName("admin");
			return mv;
		}
}
	
	
	
	@RequestMapping(value="changeRegistrationStatus.htm",method=RequestMethod.GET)
	public ModelAndView changeRegistrationStatus(@RequestParam("memberId")String memberId,@RequestParam("action")String action){
		ModelAndView mv=new ModelAndView();

		
		if(action.equals("Accept")){
		boolean acceptRegisration = memberRegistrationRequestService.acceptRegistrtionRequest(memberId);
		    if(acceptRegisration)
			mv.setViewName("admin");
		    return mv;
		}else{
			
			boolean rejectRegisration = memberRegistrationRequestService.rejectRegistrtionRequest(memberId);
			if(rejectRegisration)
			mv.setViewName("admin");
			return mv;
		}
}
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "viewmemberbyid.htm", method = RequestMethod.GET)
	public String loadMemberByIdForm() {
		return "viewmemberbyid";
	}
//	---------------------ENTER MEMBER ID
	@RequestMapping(value = "memberbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrById(@RequestParam("memberId")String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById",memberById);

		mv.setViewName("viewmemberplandetails");
		return mv;
	}

	
	
	@RequestMapping(value = "memberdetailbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrDetailById(@RequestParam("memberId")String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById",memberById);

		mv.setViewName("viewmemberdetail");
		return mv;
	}

//	-------------------------------
	@Autowired
	private PlanCodeService planCodeService;
	
	@RequestMapping(value = "editplancode.htm", method = RequestMethod.GET)
	public ModelAndView editPlanCode(@RequestParam("planCode")int planCode) {
		ModelAndView mv = new ModelAndView();

		List<PlanCode> planById = planCodeService.getPlanDetailById(planCode);

		mv.addObject("planById",planById);

		mv.setViewName("editplancode");
		return mv;
	}

	//   -----------------------------------------------ADMIN
	
	
	
}
