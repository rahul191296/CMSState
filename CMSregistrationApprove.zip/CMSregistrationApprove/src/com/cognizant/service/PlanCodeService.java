package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.PlanCode;

public interface PlanCodeService {
public List<PlanCode> getPlanDetailById(int planCode);
}
