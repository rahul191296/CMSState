package com.cognizant.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ClaimDAO;
import com.cognizant.entity.Claim;

@Service("ClaimServiceImpl")
public class ClaimServiceImpl implements ClaimService {

	@Autowired
	private ClaimDAO claimDAO;

	@Override
	public List<Claim> getNewClaim() {

		return claimDAO.getNewClaim();
	}

	@Override
	public List<Claim> getProcessedClaim() {
		return claimDAO.getProcessedClaim();

	}

	@Override
	public List<Claim> getOneClaim(int claimId) {
		return claimDAO.getOneClaim(claimId);
		
	}

	@Override
	public boolean acceptClaimRequest(int claimId, int memberId) {
		return claimDAO.acceptClaimRequest(claimId , memberId);
	}

	@Override
	public boolean rejectClaimRequest(int claimId, int memberId) {
		return claimDAO.rejectClaimRequest(claimId , memberId);
	}

}
