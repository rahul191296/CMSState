package com.cognizant.service;


import java.util.List;

import com.cognizant.entity.MemberRegistrationRequest;
import com.cognizant.model.MemberModel;


public interface MemberRegistrationRequestService {
	  public List<MemberRegistrationRequest> getAllNewRegistration();
//	  public boolean persistMemberRegistrationRequest(MemberModel memberModel);
	  public boolean acceptRegistrtionRequest(String memberId);
		public boolean rejectRegistrtionRequest(String memberId);
		 public List<MemberRegistrationRequest> getAllApprovedRegistration();
}
