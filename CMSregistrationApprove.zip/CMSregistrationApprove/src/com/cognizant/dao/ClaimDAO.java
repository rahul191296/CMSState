package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Claim;

public interface ClaimDAO {

	public List<Claim> getNewClaim();
	public List<Claim> getProcessedClaim();
	public List<Claim> getOneClaim(int claimId);
	public boolean acceptClaimRequest(int claimId,int memberId);
	public boolean rejectClaimRequest(int claimId,int memberId);
}
