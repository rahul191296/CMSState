package com.cognizant.dao;


import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cognizant.entity.Member;
import com.cognizant.entity.MemberRegistrationRequest;
import com.cognizant.model.MemberModel;

@Repository("MemberDAOImpl")

public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	
     MemberRegistrationRequest memberRegistrationRequest=new MemberRegistrationRequest();

	public boolean doLogin(MemberModel memberModel) {

		Session session = sessionFactory.openSession();
		Query query = session.getNamedQuery("findMember");
		query.setParameter("id", memberModel.getMemberId() );
		query.setParameter("pass", memberModel.getPassword());
		List<Member> memberList = query.list();

		if (memberList.isEmpty())
			return false;
		else
			return true;
	}

	
	public static String id;
	
	@Override
	public boolean insertMember(Member member) {
		generateMemberId();
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		tx.begin();
		
		session.persist(member);
		
		 memberRegistrationRequest.setMemberId(member.getMemberId());
		 memberRegistrationRequest.setRegistrationStatus("New");
		 
		session.persist(memberRegistrationRequest);
		
		tx.commit();
		id=member.getMemberId();
		session.close();
	
		return true;
	}

	@Override
	public List<Member> getMemberById(String memberId) {

		Session session = sessionFactory.openSession();
		Query query = session.getNamedQuery("getMemberById");
		query.setParameter("id", memberId);
		List<Member> member=query.list();
		return member;
	}

	@Override
	public void generateMemberId() {
		
		Session session=sessionFactory.openSession();
		Query query=session.createSQLQuery("select Member_ID.nextval FROM DUAL");
		Long key=((BigDecimal)query.uniqueResult()).longValue();
		//System.out.println("Id generated:"+key);
		MemberStoreId.addId(key.intValue());
	}

	@Override
	public String getId() {
		
		return id;
	}

	
}
	

