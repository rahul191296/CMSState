package com.cognizant.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cognizant.model.ClaimModel;

import com.cognizant.service.ClaimService;

@Component("ClaimValidator")
public class ClaimValidator implements Validator {

	@Autowired
	private ClaimService claimService;

	private Pattern pattern;
	private Matcher matcher;

	private static final String DATE_PATTERN = "^[0-3]?[0-9]/[0-z]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";
	String ID_PATTERN = "[0-9]+";
	String STRING_PATTERN = "[a-zA-Z]+";
	String MOBILE_PATTERN = "[0-9]";

	@Override
	public boolean supports(Class<?> arg0) {

		return arg0.equals(ClaimModel.class);
	}

	@Override
	public void validate(Object target, Errors errors) {

		ClaimModel claims = (ClaimModel) target;
/*
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "claimProcessingDate", "required.processingDate");
		if (!(claims.getClaimProcessingDate() != null && claims.getClaimProcessingDate().isEmpty())) {
			pattern = Pattern.compile(DATE_PATTERN);
			matcher = pattern.matcher(claims.getClaimProcessingDate());
			if (!matcher.matches()) {
				errors.rejectValue("claimProcessingDate", "claimProcessingDate.incorrect");
			}
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "claimServiceDate", "required.serviceDate");
		if (!(claims.getClaimServiceDate() != null && claims.getClaimServiceDate().isEmpty())) {
			pattern = Pattern.compile(DATE_PATTERN);
			matcher = pattern.matcher(claims.getClaimServiceDate());
			if (!matcher.matches()) {
				errors.rejectValue("claimServiceDate", "claimServiceDate.incorrect");
			}
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "claimSubmissionDate", "required.submissionDate");
		if (!(claims.getClaimSubmissionDate() != null && claims.getClaimSubmissionDate().isEmpty())) {
			pattern = Pattern.compile(DATE_PATTERN);
			matcher = pattern.matcher(claims.getClaimSubmissionDate());
			if (!matcher.matches()) {
				errors.rejectValue("claimSubmissionDate", "claimSubmissionDate.incorrect");
			}
		}
*/
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "claimAmount", "required.claimAmount");

		// phone number validation
		/*
		 * String c = Integer.toString(claims.getClaimAmount()); if (!(c != null
		 * && c.isEmpty())) { pattern = Pattern.compile(MOBILE_PATTERN); matcher
		 * = pattern.matcher(c); if (!matcher.matches()) {
		 * errors.rejectValue("claimAmount", "claimAmount.incorrect"); } }
		 */

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "approvedAmount", "required.approvedAmount");

		/*
		 * String c1 = Integer.toString(claims.getApprovedAmount()); if (!(c1 !=
		 * null && c1.isEmpty())) { matcher = pattern.matcher(c1); if
		 * (!matcher.matches()) { errors.rejectValue("approvedAmount",
		 * "approvedAmount.incorrect"); } }
		 */

	}

}
