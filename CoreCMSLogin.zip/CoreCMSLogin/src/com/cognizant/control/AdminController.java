package com.cognizant.control;


import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.cognizant.model.AdminModel;
import com.cognizant.service.AdminService;
import com.cognizant.validation.AdminRagistrationValidator;

@Controller
public class AdminController {
	@Autowired
	@Qualifier("AdminValidator")
	private Validator adminvalidator;

	@Autowired
	private AdminService adminService;

	
	@ModelAttribute("adminModel")
	public AdminModel createAdminModelObject() {
		AdminModel adminModel = new AdminModel();
		return adminModel;

	}
	
	@RequestMapping(value = "adminlogin.htm", method = RequestMethod.GET)
	public String loadLoginForm() {
		return "adminlogin";
	}

	

	@RequestMapping(value = "doadminlogin.htm", method = RequestMethod.POST)
	public ModelAndView doAdminLogin(@ModelAttribute("adminModel") AdminModel adminModel, Errors errors, HttpSession session) {
		ValidationUtils.invokeValidator(adminvalidator, adminModel, errors);
		ModelAndView mv = new ModelAndView();

		if (errors.hasErrors()) {
			mv.setViewName("adminlogin");
		} else {
	
			mv.setViewName("admin");
			}
		
		return mv;
	}
	
	@RequestMapping(value = "adminregistration.htm", method = RequestMethod.GET)
	public String loadAdminRegistrationForm() {

		return "adminregistration";
	}
	
	 @Autowired
	private AdminRagistrationValidator adminRagistrationValidator;
	  
	 
	  
	
	  @RequestMapping(value = "registerProcessAdmin.htm", method = RequestMethod.POST)
	  public ModelAndView addAdmin(@ModelAttribute("adminModel") AdminModel adminModel,Errors error) 
	  {
		 
		  ModelAndView mv=new ModelAndView();
	  ValidationUtils.invokeValidator(adminRagistrationValidator, adminModel, error);
		  
		  if(error.hasErrors())
		  {
			  mv.setViewName("adminregistration");
		  }
		 
		  else{
		  if(adminService.persistAdmin(adminModel)==true)
		  {
			  String id=adminService.getId();
			  mv.addObject("id",id);
			  mv.setViewName("registrationsuccess");
		  }
		 else
	        mv.setViewName("adminregistration");
		  }
		  return mv;
	 }

	// -----------------------------------------------------------------LOGOUT

	@RequestMapping(value = "logout.htm", method = RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		session.invalidate();
		mv.setViewName("logoutpage");
		return mv;
	}

	
	
}
