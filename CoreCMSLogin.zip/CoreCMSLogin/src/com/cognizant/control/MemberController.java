package com.cognizant.control;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Claim;
import com.cognizant.entity.Member;
import com.cognizant.entity.MemberRegistrationRequest;
import com.cognizant.entity.PlanCode;
import com.cognizant.model.ClaimModel;
import com.cognizant.model.MemberModel;
import com.cognizant.service.ClaimService;
import com.cognizant.service.MemberRegistrationRequestService;
import com.cognizant.service.MemberService;
import com.cognizant.service.PlanCodeService;
import com.cognizant.validation.MemberRegistrationValidator;

@Controller
public class MemberController {

	@Autowired
	private MemberRegistrationValidator memberRagistrationValidator;

	@Autowired
	private MemberRegistrationRequestService memberRegistrationRequestService;

	// -----------------------------------------------ADMIN

	@Autowired
	private ClaimService claimService;
	
	@Autowired
	private PlanCodeService planCodeService;

	@Autowired
	@Qualifier("MemberValidator")
	private Validator membervalidator;

	@Autowired
	private MemberService memberService;

	@Autowired
	@Qualifier("ClaimValidator")
	private Validator claimvalidator;

	@ModelAttribute("memberModel")
	public MemberModel createMemberModelObject() {
		MemberModel memberModel = new MemberModel();
		return memberModel;
	}

	@RequestMapping(value = "memberlogin.htm", method = RequestMethod.GET)
	public String VendorLoginForm() {
		return "memberlogin";
	}

	@RequestMapping(value = "domemberlogin.htm", method = RequestMethod.POST)
	public ModelAndView doMemberLogin(@ModelAttribute("memberModel") MemberModel memberModel, Errors errors,
			HttpSession session) {
		List<MemberRegistrationRequest> ApprovedMemberList = memberRegistrationRequestService
				.getAllApprovedRegistration();

		String registrationStatus = "New";
		String memberStatusId = memberModel.getMemberId();
		// ADD MEMBER ID IN SESSION
		session.setAttribute("memberStatusId", memberStatusId);

		for (MemberRegistrationRequest temp : ApprovedMemberList) {
			if (temp.getMemberId().equals(memberStatusId)) {
				registrationStatus = temp.getRegistrationStatus();
				break;

			}
		}

		ValidationUtils.invokeValidator(membervalidator, memberModel, errors);
		ModelAndView mv = new ModelAndView();
		if (errors.hasErrors()) {
			mv.setViewName("memberlogin");
		} else {
			if (registrationStatus.equals("Approved")) {
				mv.addObject("memberStatusId", memberStatusId);
				mv.setViewName("member");
			} else {
				mv.setViewName("memberlogin");
			}
		}
		return mv;
	}

	@RequestMapping(value = "memberregistration.htm", method = RequestMethod.GET)
	public ModelAndView loadMemberRegistrationForm() {
		ModelAndView mv= new ModelAndView();
		
		List<PlanCode> planCodeList = planCodeService.getPlanCodeList();
		
		mv.addObject("planCodeList",planCodeList);
		
		mv.setViewName("memberregistration");
		return mv;
	}

	@RequestMapping(value = "registerProcessMember.htm", method = RequestMethod.POST)
	public ModelAndView AddMember(@ModelAttribute("memberModel") MemberModel memberModel, Errors error) {

		ModelAndView mv = new ModelAndView();
		ValidationUtils.invokeValidator(memberRagistrationValidator, memberModel, error);

		if (error.hasErrors()) {
			mv.setViewName("memberregistration");
		} else {
			if (memberService.persistMember(memberModel) == true) {

				String id = memberService.getId();
				mv.addObject("id", id);
				mv.setViewName("memberregisuccess");
			} else
				mv.setViewName("memberregistration");
		}
		return mv;

	}

	// ---------------------ENTER MEMBER ID

	@RequestMapping(value = "viewmemberbyid.htm", method = RequestMethod.GET)
	public String loadMemberByIdForm() {
		return "viewmemberbyid";
	}

	@RequestMapping(value = "memberbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrById(@RequestParam("memberId") String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById", memberById);

		mv.setViewName("viewmemberplandetails");
		return mv;
	}

	@RequestMapping(value = "memberdetailbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrDetailById(@RequestParam("memberId") String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById", memberById);

		mv.setViewName("viewmemberdetail");
		return mv;
	}

	@RequestMapping(value = "changeRegistrationStatus.htm", method = RequestMethod.GET)
	public ModelAndView changeRegistrationStatus(@RequestParam("memberId") String memberId,
			@RequestParam("action") String action) {
		ModelAndView mv = new ModelAndView();

		if (action.equals("Accept")) {
			boolean acceptRegisration = memberRegistrationRequestService.acceptRegistrtionRequest(memberId);
			if (acceptRegisration)
				mv.setViewName("admin");
			return mv;
		} else {

			boolean rejectRegisration = memberRegistrationRequestService.rejectRegistrtionRequest(memberId);
			if (rejectRegisration)
				mv.setViewName("admin");
			return mv;
		}
	}

	@RequestMapping(value = "viewnewmember.htm", method = RequestMethod.GET)
	public ModelAndView viewNewMember() {
		ModelAndView mv = new ModelAndView();
		List<MemberRegistrationRequest> newMemberList = memberRegistrationRequestService.getAllNewRegistration();
		mv.addObject("newMemberList", newMemberList);

		mv.setViewName("viewnewmember");
		return mv;
	}

	@RequestMapping(value = "raiseclaimform.htm", method = RequestMethod.GET)
	public String loadRaiseClaimForm() {
		return "raiseclaimform";
	}

	@RequestMapping(value = "claimregistrationprocess.htm", method = RequestMethod.POST)
	public ModelAndView addClaim(@ModelAttribute("claimModel") ClaimModel claimModel, Errors error,
			HttpSession session) {

		// GET MEMBER ID FROM SESSION
		String memberSId = (String) session.getAttribute("memberStatusId");

		ModelAndView mv = new ModelAndView();
		ValidationUtils.invokeValidator(claimvalidator, claimModel, error);

		if (error.hasErrors()) {
			mv.setViewName("raiseclaimform");
		}

		else {
			claimModel.setMemberId(memberSId);
			claimModel.setClaimStatus("Submitted");
			if (claimService.persistClaim(claimModel) == true) {
				mv.setViewName("claimregistrationsuccess");

			} else {
				mv.setViewName("raiseclaimform");
			}
		}

		return mv;

	}

	@RequestMapping(value = "viewAllClaimOfMember.htm", method = RequestMethod.GET)
	public ModelAndView viewAllClaimOfMember(HttpSession session) {
		ModelAndView mv = new ModelAndView();

		String memberCId = (String) session.getAttribute("memberStatusId");
		List<Claim> memberClaimsList = claimService.getClaimListOfMember(memberCId);

		mv.addObject("memberClaimsList", memberClaimsList);

		mv.setViewName("memberclaimdetail");
		return mv;
	}

	@ModelAttribute("claimModel")
	public ClaimModel createClaimModelObject() {
		ClaimModel claimModel = new ClaimModel();
		return claimModel;
	}

}
