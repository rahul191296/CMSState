package com.cognizant.control;

public class MemberController {

}
