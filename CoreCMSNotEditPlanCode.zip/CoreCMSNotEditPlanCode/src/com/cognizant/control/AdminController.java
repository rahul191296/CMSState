package com.cognizant.control;

import java.util.List;

import javax.servlet.http.HttpSession;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;


import com.cognizant.entity.Claim;
import com.cognizant.entity.Member;
import com.cognizant.entity.MemberRegistrationRequest;
import com.cognizant.entity.PlanCode;
import com.cognizant.model.AdminModel;
import com.cognizant.model.ClaimModel;
import com.cognizant.model.MemberModel;
import com.cognizant.service.AdminService;
import com.cognizant.service.ClaimService;
import com.cognizant.service.MemberRegistrationRequestService;
import com.cognizant.service.MemberService;
import com.cognizant.service.PlanCodeService;
import com.cognizant.validation.AdminRagistrationValidator;
import com.cognizant.validation.MemberRegistrationValidator;


@Controller

public class AdminController {
	@Autowired
	@Qualifier("AdminValidator")
	private Validator adminvalidator;

	@Autowired
	@Qualifier("MemberValidator")
	private Validator membervalidator;
	
	@Autowired
	@Qualifier("ClaimValidator")
	private Validator claimvalidator;
	
	@Autowired
	private ClaimService claimService;
	
	@Autowired
	private MemberRegistrationRequestService memberRegistrationRequestService;
	
     //   -----------------------------------------------ADMIN
	@Autowired
	private AdminService adminService;

	
	@ModelAttribute("adminModel")
	public AdminModel createAdminModelObject() {
		AdminModel adminModel = new AdminModel();
		return adminModel;

	}
	
	@RequestMapping(value = "adminlogin.htm", method = RequestMethod.GET)
	public String loadLoginForm() {
		return "adminlogin";
	}

	

	@RequestMapping(value = "doadminlogin.htm", method = RequestMethod.POST)
	public ModelAndView doAdminLogin(@ModelAttribute("adminModel") AdminModel adminModel, Errors errors, HttpSession session) {
		ValidationUtils.invokeValidator(adminvalidator, adminModel, errors);
		ModelAndView mv = new ModelAndView();

		if (errors.hasErrors()) {
			mv.setViewName("adminlogin");
		} else {
	
			mv.setViewName("admin");
			}
		
		return mv;
	}
	
	@RequestMapping(value = "adminregistration.htm", method = RequestMethod.GET)
	public String loadAdminRegistrationForm() {

		return "adminregistration";
	}
	
	 @Autowired
	  private AdminRagistrationValidator adminRagistrationValidator;
	  
	 
	  
	
	  @RequestMapping(value = "registerProcessAdmin.htm", method = RequestMethod.POST)
	  public ModelAndView addAdmin(@ModelAttribute("adminModel") AdminModel adminModel,Errors error) 
	  {
		 
		  ModelAndView mv=new ModelAndView();
	  ValidationUtils.invokeValidator(adminRagistrationValidator, adminModel, error);
		  
		  if(error.hasErrors())
		  {
			  mv.setViewName("adminregistration");
		  }
		 
		  else{
		  if(adminService.persistAdmin(adminModel)==true)
		  {
			  String id=adminService.getId();
			  mv.addObject("id",id);
			  mv.setViewName("registrationsuccess");
		  }
		 else
	        mv.setViewName("adminregistration");
		  }
		  return mv;
	 }

	// ---------------------------------------------------------
	

	
	// -------------------------------------------------------MEMBER
	  
	  @Autowired
	  private MemberRegistrationValidator memberRagistrationValidator;  
	
	@ModelAttribute("memberModel")
	public MemberModel createMemberModelObject() {
		MemberModel memberModel = new MemberModel();
		return memberModel;
	}
	
	
	@RequestMapping(value = "memberlogin.htm", method = RequestMethod.GET)
	public String VendorLoginForm() {
		return "memberlogin";
	}

	
	
	
	@RequestMapping(value = "domemberlogin.htm", method = RequestMethod.POST)
	public ModelAndView doMemberLogin(@ModelAttribute("memberModel") MemberModel memberModel, Errors errors, HttpSession session) {
		List<MemberRegistrationRequest>  ApprovedMemberList =  memberRegistrationRequestService.getAllApprovedRegistration();
		
		String	registrationStatus="New";
	    String	memberStatusId=memberModel.getMemberId();
	                                                        // ADD MEMBER ID IN SESSION
	    session.setAttribute("memberStatusId" , memberStatusId);
	
	    for(MemberRegistrationRequest temp : ApprovedMemberList){
	  	if(temp.getMemberId().equals(memberStatusId)){
	    	registrationStatus=	temp.getRegistrationStatus();
	         break;
	    	
	    	}
	    	}
	
	    ValidationUtils.invokeValidator(membervalidator, memberModel, errors);
		ModelAndView mv = new ModelAndView();
		if (errors.hasErrors()) {
			mv.setViewName("memberlogin");
	} else {
	if(registrationStatus.equals("Approved")){
		mv.addObject("memberStatusId",memberStatusId);
			mv.setViewName("member");
			}
		else{
			mv.setViewName("memberlogin");
		}
		}
		return mv;
	}
	
	
	@RequestMapping(value = "memberregistration.htm", method = RequestMethod.GET)
	public String loadMemberRegistrationForm() {
		return "memberregistration";
	}
	
	
	
	 
	 
	 @RequestMapping(value = "registerProcessMember.htm", method = RequestMethod.POST)
	  public ModelAndView AddMember(@ModelAttribute("memberModel") MemberModel memberModel,Errors error) 
	  {
		 
		  ModelAndView mv=new ModelAndView();
		  ValidationUtils.invokeValidator(memberRagistrationValidator, memberModel, error);
		 
		  if(error.hasErrors())
		  {
			  mv.setViewName("memberregistration");
		  }
		  else
		  {
		
			  
			  
	  if(memberService.persistMember(memberModel)==true)
	  {
	
		  String id=memberService.getId();
		  mv.addObject("id",id);
	  mv.setViewName("memberregisuccess");
	  }
	  else
		  mv.setViewName("memberregistration");
		  }
	return mv;
	 
	  }
   //  ------------- RAISE CLAIM-
	 
	 @ModelAttribute("claimModel")
		public ClaimModel createClaimModelObject() {
			ClaimModel claimModel = new ClaimModel();
			return claimModel;
		}
	 
	 
	 
	 
		@RequestMapping(value = "raiseclaimform.htm", method = RequestMethod.GET)
		public String loadRaiseClaimForm() {
			return "raiseclaimform";
		}
	
		@RequestMapping(value = "claimregistrationprocess.htm", method = RequestMethod.POST)
		public ModelAndView addClaim(@ModelAttribute("claimModel") ClaimModel claimModel, Errors error,HttpSession session) {
                                                                    
			                                                            // GET MEMBER ID FROM SESSION
		String memberSId=(String)session.getAttribute("memberStatusId");
			
		
			ModelAndView mv = new ModelAndView();
			ValidationUtils.invokeValidator(claimvalidator, claimModel, error);

			if (error.hasErrors()) {
				mv.setViewName("raiseclaimform");
			}
			
			else{
				claimModel.setMemberId(memberSId);
				claimModel.setClaimStatus("Submitted");
				if (claimService.persistClaim(claimModel) == true) {
					mv.setViewName("claimregistrationsuccess");

				} else {
					mv.setViewName("raiseclaimform");
				} 
			}
			
			return mv;

		}
	
// #############################################################################################
		@RequestMapping(value = "viewAllClaimOfMember.htm", method = RequestMethod.GET)
		public ModelAndView viewAllClaimOfMember(HttpSession session) {
			ModelAndView mv = new ModelAndView();
			String memberCId=(String)session.getAttribute("memberStatusId");
			List<Claim> memberClaimsList = claimService.getClaimListOfMember(memberCId);

			mv.addObject("memberClaimsList", memberClaimsList );

			mv.setViewName("memberclaimdetail");
			return mv;
		}
		

		@RequestMapping(value = "viewonememberclaim.htm", method = RequestMethod.GET)
		public ModelAndView viewOneMemberClaim(@RequestParam("claimId")int claimId) {
			ModelAndView mv = new ModelAndView();

			List<Claim> oneMemberClaim = claimService.getOneClaim(claimId);

			mv.addObject("oneMemberClaim",oneMemberClaim);

			mv.setViewName("viewonememberclaim");
			return mv;
		}

	// ----------------MEMBER REGISTRATION STATUS

	
	@RequestMapping(value = "viewnewmember.htm", method = RequestMethod.GET)
	public ModelAndView viewNewMember() {
 	    ModelAndView mv = new ModelAndView();
 	   List<MemberRegistrationRequest> newMemberList = memberRegistrationRequestService.getAllNewRegistration(); 
		mv.addObject("newMemberList",newMemberList);
		
		mv.setViewName("viewnewmember");
		return mv;
	}
	
	
	// -----------------------------------------------------------------LOGOUT

	@RequestMapping(value = "logout.htm", method = RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		session.invalidate();
		mv.setViewName("logoutpage");
		return mv;
	}

	//-------------------------------------------------------------------------CLAIM
	
	

	@RequestMapping(value = "viewnewclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewNewClaim() {
		ModelAndView mv = new ModelAndView();

		List<Claim> newClaimList = claimService.getNewClaim();
	
		mv.addObject("newClaimList", newClaimList);

		mv.setViewName("viewnewclaim");
		return mv;
	}
	
	
	

	@RequestMapping(value = "viewprocessedclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewProcessedClaim() {
		ModelAndView mv = new ModelAndView();

		List<Claim> processedClaimList = claimService.getProcessedClaim();

		mv.addObject("processedClaimList", processedClaimList );

		mv.setViewName("viewprocessedclaim");
		return mv;
	}
   
	
	@RequestMapping(value = "viewoneclaim.htm", method = RequestMethod.GET)
	public ModelAndView viewOneClaim(@RequestParam("claimId")int claimId) {
		ModelAndView mv = new ModelAndView();

		List<Claim> oneClaim = claimService.getOneClaim(claimId);

		mv.addObject("oneClaim",oneClaim);

		mv.setViewName("viewoneclaim");
		return mv;
	}
	//-------------------------------------------------------------Claim Processing
	
	@RequestMapping(value="changeRequestStatus.htm",method=RequestMethod.GET)
	public ModelAndView changeClaimStatus(@RequestParam("claimId")int claimId,@RequestParam("memberId")String memberId,@RequestParam("action")String action){
		ModelAndView mv=new ModelAndView();

		
		if(action.equals("Accept")){
		boolean acceptClaim=claimService.acceptClaimRequest(claimId , memberId);
		    if(acceptClaim)
			mv.setViewName("admin");
		    return mv;
		}else{
			
			boolean rejectClaim = claimService.rejectClaimRequest(claimId, memberId);
			if(rejectClaim)
			mv.setViewName("admin");
			return mv;
		}
}
	
	
	
	@RequestMapping(value="changeRegistrationStatus.htm",method=RequestMethod.GET)
	public ModelAndView changeRegistrationStatus(@RequestParam("memberId")String memberId,@RequestParam("action")String action){
		ModelAndView mv=new ModelAndView();

		
		if(action.equals("Accept")){
		boolean acceptRegisration = memberRegistrationRequestService.acceptRegistrtionRequest(memberId);
		    if(acceptRegisration)
			mv.setViewName("admin");
		    return mv;
		}else{
			
			boolean rejectRegisration = memberRegistrationRequestService.rejectRegistrtionRequest(memberId);
			if(rejectRegisration)
			mv.setViewName("admin");
			return mv;
		}
}
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "viewmemberbyid.htm", method = RequestMethod.GET)
	public String loadMemberByIdForm() {
		return "viewmemberbyid";
	}
//	---------------------ENTER MEMBER ID
	@RequestMapping(value = "memberbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrById(@RequestParam("memberId")String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById",memberById);

		mv.setViewName("viewmemberplandetails");
		return mv;
	}

	
	
	@RequestMapping(value = "memberdetailbyid.htm", method = RequestMethod.GET)
	public ModelAndView veiwMemebrDetailById(@RequestParam("memberId")String memberId) {
		ModelAndView mv = new ModelAndView();

		List<Member> memberById = memberService.getMemberById(memberId);

		mv.addObject("memberById",memberById);

		mv.setViewName("viewmemberdetail");
		return mv;
	}

//	-------------------------------
	@Autowired
	private PlanCodeService planCodeService;
	
	@RequestMapping(value = "editplancode.htm", method = RequestMethod.GET)
	public ModelAndView editPlanCode(@RequestParam("planCode")String planCode) {
		ModelAndView mv = new ModelAndView();

		List<PlanCode> planById = planCodeService.getPlanDetailById(planCode);

		mv.addObject("planById",planById);

		mv.setViewName("editplancode");
		return mv;
	}

	//   -----------------------------------------------ADMIN
	
	
	
}
