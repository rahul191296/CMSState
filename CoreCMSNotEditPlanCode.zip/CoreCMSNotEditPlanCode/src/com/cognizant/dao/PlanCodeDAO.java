package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.PlanCode;

public interface PlanCodeDAO {
	public List<PlanCode> getPlanDetailById(String planCode);
}
