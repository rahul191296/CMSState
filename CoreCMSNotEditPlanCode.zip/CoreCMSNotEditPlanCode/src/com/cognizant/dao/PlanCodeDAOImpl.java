package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.PlanCode;

@Repository("PlanCodeDAOImpl")
public class PlanCodeDAOImpl implements PlanCodeDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<PlanCode> getPlanDetailById(String planCode) {

		Session session = sessionFactory.openSession();
		Query query = session.getNamedQuery("getPlanById");

		query.setParameter("planCode", planCode);
		List<PlanCode> onePlan = query.list();
		return onePlan;

	}

}
